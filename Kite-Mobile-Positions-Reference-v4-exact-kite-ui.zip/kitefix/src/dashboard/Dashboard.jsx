import { useMemo, useState } from 'react'

const seedPositions = [
  { id: 1, symbol: 'ADANIENT', qty: 60, avg: 3088.2, ltp: 3017.75, direction: 'SELL' },
]

function money(value) {
  const sign = value >= 0 ? '+' : '-'
  return `${sign}₹${Math.abs(value).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`
}

function price(value) {
  return value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

function calculatePnl(position) {
  const difference = position.direction === 'BUY' ? position.ltp - position.avg : position.avg - position.ltp
  return difference * position.qty
}

function calculatePnlPct(position) {
  return position.avg ? (calculatePnl(position) / (position.avg * position.qty)) * 100 : 0
}

function Icon({ name, size = 24 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }
  const paths = {
    search: <><circle cx="10.8" cy="10.8" r="6.6" /><path d="m16 16 5 5" /></>,
    filter: <><path d="M4 6h16M4 12h16M4 18h16" /><path d="M8 4v4M15 10v4M11 16v4" /></>,
    bag: <><rect x="4" y="7" width="16" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></>,
    family: <><circle cx="9" cy="8" r="3" /><circle cx="17" cy="9" r="2.3" /><path d="M3.5 20c.5-3.4 2.4-5.2 5.5-5.2s5 1.8 5.5 5.2" /><path d="M14.5 15.1c2.8-.1 4.8 1.4 5.4 4.2" /></>,
    analytics: <><path d="M12 3a9 9 0 1 0 9 9" /><path d="M12 3v9h9" /></>,
    bookmark: <path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4Z" />,
    orders: <><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M8 17h8" /></>,
    portfolio: <><rect x="3.5" y="6.5" width="17" height="14" rx="2" /><path d="M8 6.5V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1.5" /></>,
    bids: <><path d="m5 19 12-12" /><path d="m4 15 5 5" /><path d="m15 4 5 5" /><path d="m14 6 4 4" /></>,
    profile: <><circle cx="12" cy="8" r="3.2" /><path d="M5 21c.8-4 3.1-6 7-6s6.2 2 7 6" /></>,
    trend: <><path d="m4 16 5-5 3 3 7-7" /><path d="M14 7h5v5" /></>,
  }
  return <svg {...common}>{paths[name]}</svg>
}

function PositionForm({ onAdd, onClose }) {
  const [form, setForm] = useState({ symbol: '', qty: '', avg: '', ltp: '', direction: 'BUY' })
  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))
  const submit = (event) => {
    event.preventDefault()
    const symbol = form.symbol.trim().toUpperCase()
    const qty = Number(form.qty)
    const avg = Number(form.avg)
    const ltp = Number(form.ltp)
    if (!symbol || qty <= 0 || avg < 0 || ltp < 0) return
    onAdd({ symbol, qty, avg, ltp, direction: form.direction })
  }

  return (
    <form className="position-form" onSubmit={submit}>
      <div className="form-heading"><div><h3>Add position</h3><p>Enter position details</p></div><button type="button" className="close-btn" onClick={onClose}>×</button></div>
      <div className="direction-switch"><button type="button" className={form.direction === 'BUY' ? 'active buy' : ''} onClick={() => update('direction', 'BUY')}>BUY</button><button type="button" className={form.direction === 'SELL' ? 'active sell' : ''} onClick={() => update('direction', 'SELL')}>SELL</button></div>
      <label>Stock / Symbol<input value={form.symbol} onChange={(e) => update('symbol', e.target.value)} placeholder="RELIANCE" required /></label>
      <div className="form-grid"><label>Quantity<input type="number" min="1" value={form.qty} onChange={(e) => update('qty', e.target.value)} placeholder="100" required /></label><label>Average price<input type="number" min="0" step="0.01" value={form.avg} onChange={(e) => update('avg', e.target.value)} placeholder="1400" required /></label><label>LTP<input type="number" min="0" step="0.01" value={form.ltp} onChange={(e) => update('ltp', e.target.value)} placeholder="1470" required /></label></div>
      <button className="primary-btn" type="submit">Add position</button>
    </form>
  )
}

export default function Dashboard() {
  const [positions, setPositions] = useState(seedPositions)
  const [showForm, setShowForm] = useState(false)
  const [activeTab, setActiveTab] = useState('Positions')
  const totalPnl = useMemo(() => positions.reduce((sum, position) => sum + calculatePnl(position), 0), [positions])
  const totalPnlPct = useMemo(() => positions.length ? positions.reduce((sum, position) => sum + calculatePnlPct(position), 0) : 0, [positions])

  const addPosition = (position) => {
    setPositions((current) => [...current, { ...position, id: Date.now() }])
    setShowForm(false)
  }

  const removePosition = (id) => setPositions((current) => current.filter((position) => position.id !== id))

  return (
    <div className="trading-shell">
      <header className="trading-header">
        <div className="mobile-portfolio-title">Portfolio</div>
        <div className="mobile-chevron" aria-hidden="true" />
      </header>

      <main className="dashboard-main">
        <div className="mobile-tabs">
          <button className={activeTab === 'Holdings' ? 'active' : ''} onClick={() => setActiveTab('Holdings')}>Holdings <span className="tab-count holdings-count">7</span></button>
          <button className={activeTab === 'Positions' ? 'active' : ''} onClick={() => setActiveTab('Positions')}>Positions <span className="tab-count positions-count">{positions.length}</span></button>
        </div>

        {activeTab === 'Positions' ? (
          <>
            <section className="total-pnl-card">
              <span>Total P&amp;L</span>
              <strong className={totalPnl >= 0 ? 'positive' : 'negative'}>{money(totalPnl)}</strong>
            </section>

            <div className="mobile-tools">
              <button aria-label="Search"><Icon name="search" /></button>
              <button aria-label="Filter"><Icon name="filter" /></button>
              <button aria-label="Portfolio"><Icon name="bag" /></button>
              <button className="equity-button" aria-label="Equity">Equity <span className="mini-chevron" /></button>
              <button className="family-button" aria-label="Family"><Icon name="family" size={28} /><span>Family</span></button>
              <button className="analytics-button" aria-label="Analytics"><Icon name="analytics" size={29} /><span>Analytics</span></button>
            </div>

            <section className="positions-card kite-positions-screen">
              {positions.length === 0 ? (
                <div className="kite-empty-state">
                  <div className="empty-illustration" aria-hidden="true"><div className="paper one" /><div className="paper two" /><div className="paper three" /></div>
                  <h2>No positions</h2>
                  <p>Place an order from your watchlist</p>
                </div>
              ) : (
                <div className="positions-list">
                  {positions.map((position) => {
                    const pnl = calculatePnl(position)
                    const pnlPct = calculatePnlPct(position)
                    return (
                      <article className="kite-position" key={position.id}>
                        <div className="position-summary-row">
                          <div className="summary-left"><span>Qty. {position.direction === 'SELL' ? `-${position.qty}` : position.qty}</span><span className="bullet">•</span><span>Avg. {price(position.avg)}</span></div>
                          <strong className={pnlPct >= 0 ? 'positive' : 'negative'}>{pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(2)}%</strong>
                        </div>
                        <div className="position-main-row">
                          <div className="position-symbol-block"><div className="position-symbol-line"><strong>{position.symbol}</strong><span className={`direction ${position.direction.toLowerCase()}`}>{position.direction}</span></div><span className="exchange-label">NSE</span></div>
                          <strong className={pnl >= 0 ? 'positive' : 'negative'}>{money(pnl)}</strong>
                        </div>
                        <div className="position-detail-row"><div><span>LTP</span><strong>{price(position.ltp)} <em className={pnlPct >= 0 ? 'positive' : 'negative'}>({pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(2)}%)</em></strong></div><button className="delete-btn" onClick={() => removePosition(position.id)} aria-label={`Remove ${position.symbol}`}>×</button></div>
                      </article>
                    )
                  })}
                </div>
              )}
            </section>

            <div className="day-pnl-bar"><span>Day's P&amp;L</span><strong className={totalPnl >= 0 ? 'positive' : 'negative'}>{money(totalPnl)}</strong><strong className={totalPnlPct >= 0 ? 'positive' : 'negative'}>{totalPnlPct.toFixed(2)}%</strong></div>
          </>
        ) : (
          <section className="holdings-panel"><h2>Holdings</h2><p>Holdings are shown in the Holdings tab.</p></section>
        )}
      </main>

      <button className="position-fab" onClick={() => setShowForm(true)} aria-label="Add position"><Icon name="trend" size={31} /></button>

      <nav className="mobile-bottom-nav">
        <button><Icon name="bookmark" /><span>Watchlist</span></button>
        <button><Icon name="orders" /><span>Orders</span></button>
        <button className="active" onClick={() => setActiveTab('Positions')}><Icon name="portfolio" /><span>Portfolio</span></button>
        <button><Icon name="bids" /><span>Bids</span></button>
        <button><Icon name="profile" /><span>Profile</span></button>
      </nav>

      {showForm && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowForm(false)}><PositionForm onAdd={addPosition} onClose={() => setShowForm(false)} /></div>}
    </div>
  )
}
