import React, { useEffect, useMemo, useState } from "react";
import { positions as defaultPositions } from "../data/data.jsx";

const STORAGE_KEY = "kite_demo_positions_v1";

const readPositions = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch (_) {}
  return defaultPositions.map((p) => ({ ...p }));
};

const money = (value) => Number(value || 0).toFixed(2);

const Positions = () => {
  const [rows, setRows] = useState(readPositions);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
  }, [rows]);

  const totalPnl = useMemo(
    () => rows.reduce((sum, p) => sum + ((Number(p.price) - Number(p.avg)) * Number(p.qty)), 0),
    [rows]
  );

  const openEdit = (position) => {
    setEditing(position);
    setForm({
      product: position.product || "CNC",
      name: position.name || "",
      qty: position.qty ?? 0,
      avg: position.avg ?? 0,
      price: position.price ?? 0,
      day: position.day || "0.00%",
    });
  };

  const openAdd = () => {
    setEditing(null);
    setForm({ product: "CNC", name: "", qty: 1, avg: 0, price: 0, day: "0.00%" });
    setShowAdd(true);
  };

  const closeModal = () => {
    setEditing(null);
    setShowAdd(false);
  };

  const updateField = (key, value) => {
    setForm((old) => ({ ...old, [key]: value }));
  };

  const savePosition = (event) => {
    event.preventDefault();

    const normalized = {
      product: String(form.product || "CNC").toUpperCase(),
      name: String(form.name || "").trim().toUpperCase(),
      qty: Number(form.qty),
      avg: Number(form.avg),
      price: Number(form.price),
      day: String(form.day || "0.00%"),
      isLoss: String(form.day || "").includes("-"),
    };

    if (!normalized.name || !Number.isFinite(normalized.qty) ||
        !Number.isFinite(normalized.avg) || !Number.isFinite(normalized.price)) return;

    if (editing) {
      setRows((old) => old.map((p) => (p === editing ? normalized : p)));
    } else {
      setRows((old) => [...old, normalized]);
    }
    closeModal();
  };

  const deletePosition = (position) => {
    if (window.confirm(`Delete ${position.name} from Positions?`)) {
      setRows((old) => old.filter((p) => p !== position));
    }
  };

  const resetPositions = () => {
    if (window.confirm("Reset positions to the original demo data?")) {
      setRows(defaultPositions.map((p) => ({ ...p })));
    }
  };

  return (
    <div className="positions-page">
      <div className="positions-toolbar">
        <div>
          <h3 className="title">Positions ({rows.length})</h3>
          <span className={`positions-total ${totalPnl >= 0 ? "profit" : "loss"}`}>
            Total P&amp;L {totalPnl >= 0 ? "+" : "-"}₹{money(Math.abs(totalPnl))}
          </span>
        </div>
        <div className="positions-actions">
          <button type="button" className="position-action secondary" onClick={resetPositions}>Reset</button>
          <button type="button" className="position-action primary" onClick={openAdd}>+ Add position</button>
        </div>
      </div>

      <div className="order-table positions-table">
        <table>
          <thead>
            <tr>
              <th>Product</th><th>Instrument</th><th>Qty.</th><th>Avg.</th>
              <th>LTP</th><th>P&amp;L</th><th>Chg.</th><th aria-label="Actions"></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan="8" className="empty-positions">No positions</td></tr>
            ) : rows.map((stock, index) => {
              const pnl = (Number(stock.price) - Number(stock.avg)) * Number(stock.qty);
              const isProfit = pnl >= 0;
              return (
                <tr key={`${stock.name}-${index}`} className="position-row">
                  <td>{stock.product}</td>
                  <td className="instrument-cell">{stock.name}</td>
                  <td>{stock.qty}</td>
                  <td>{money(stock.avg)}</td>
                  <td>{money(stock.price)}</td>
                  <td className={isProfit ? "profit" : "loss"}>
                    {isProfit ? "+" : "-"}{money(Math.abs(pnl))}
                  </td>
                  <td className={String(stock.day).includes("-") ? "loss" : "profit"}>{stock.day}</td>
                  <td className="row-actions">
                    <button type="button" onClick={() => openEdit(stock)}>Edit</button>
                    <button type="button" className="delete" onClick={() => deletePosition(stock)}>Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {(editing || showAdd) && (
        <div className="position-modal-backdrop" onMouseDown={closeModal}>
          <form className="position-modal" onSubmit={savePosition} onMouseDown={(e) => e.stopPropagation()}>
            <div className="position-modal-header">
              <h3>{editing ? `Edit ${editing.name}` : "Add position"}</h3>
              <button type="button" className="modal-close" onClick={closeModal}>×</button>
            </div>

            <div className="position-form-grid">
              <label>Product
                <select value={form.product} onChange={(e) => updateField("product", e.target.value)}>
                  <option>CNC</option><option>MIS</option>
                </select>
              </label>
              <label>Instrument
                <input value={form.name} onChange={(e) => updateField("name", e.target.value)} placeholder="e.g. RELIANCE" autoFocus />
              </label>
              <label>Qty.
                <input type="number" step="1" value={form.qty} onChange={(e) => updateField("qty", e.target.value)} />
              </label>
              <label>Avg.
                <input type="number" step="0.05" value={form.avg} onChange={(e) => updateField("avg", e.target.value)} />
              </label>
              <label>LTP
                <input type="number" step="0.05" value={form.price} onChange={(e) => updateField("price", e.target.value)} />
              </label>
              <label>Chg.
                <input value={form.day} onChange={(e) => updateField("day", e.target.value)} placeholder="-1.25%" />
              </label>
            </div>

            <div className="position-modal-footer">
              <button type="button" className="position-action secondary" onClick={closeModal}>Cancel</button>
              <button type="submit" className="position-action primary">Save position</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default Positions;
