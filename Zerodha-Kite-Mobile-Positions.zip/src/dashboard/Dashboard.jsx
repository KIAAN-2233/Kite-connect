import { useMemo, useState } from 'react'

const seedPositions = [
  { id: 1, symbol: 'RELIANCE', qty: 100, avg: 1400, ltp: 1470, direction: 'BUY' },
  { id: 2, symbol: 'TCS', qty: 50, avg: 3200, ltp: 3050, direction: 'SELL' },
  { id: 3, symbol: 'HDFCBANK', qty: 200, avg: 1650, ltp: 1720, direction: 'BUY' },
]

function money(value) {
  const sign = value >= 0 ? '+' : '-'
  return `${sign}₹${Math.abs(value).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`
}

function calculatePnl(position) {
  const difference = position.direction === 'BUY' ? position.ltp - position.avg : position.avg - position.ltp
  return difference * position.qty
}

function PositionForm({ onAdd, onClose }) {
  const [form, setForm] = useState({ symbol: '', qty: '', avg: '', ltp: '', direction: 'BUY' })

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))

  const submit = (event) => {
    event.preventDefault()
    const symbol = form.symbol.trim().toUpperCase()
    const qty = Number(form.qty)
    const avg = Number(form.avg)
    const ltp = Number(form.ltp)
    if (!symbol || qty <= 0 || avg < 0 || ltp < 0) return
    onAdd({ symbol, qty, avg, ltp, direction: form.direction })
  }

  return (
    <form className="position-form" onSubmit={submit}>
      <div className="form-heading">
        <div>
          <h3>Add Position</h3>
          <p>Add a position</p>
        </div>
        <button type="button" className="close-btn" onClick={onClose}>×</button>
      </div>

      <div className="direction-switch">
        <button type="button" className={form.direction === 'BUY' ? 'active buy' : ''} onClick={() => update('direction', 'BUY')}>BUY</button>
        <button type="button" className={form.direction === 'SELL' ? 'active sell' : ''} onClick={() => update('direction', 'SELL')}>SELL</button>
      </div>

      <label>Stock / Symbol<input value={form.symbol} onChange={(e) => update('symbol', e.target.value)} placeholder="e.g. RELIANCE" required /></label>
      <div className="form-grid">
        <label>Quantity<input type="number" min="1" value={form.qty} onChange={(e) => update('qty', e.target.value)} placeholder="100" required /></label>
        <label>Average Price<input type="number" min="0" step="0.01" value={form.avg} onChange={(e) => update('avg', e.target.value)} placeholder="1400" required /></label>
        <label>LTP<input type="number" min="0" step="0.01" value={form.ltp} onChange={(e) => update('ltp', e.target.value)} placeholder="1470" required /></label>
      </div>
      <button className="primary-btn" type="submit">Add Position</button>
    </form>
  )
}

export default function Dashboard() {
  const [positions, setPositions] = useState(seedPositions)
  const [showForm, setShowForm] = useState(false)
  const [activeTab, setActiveTab] = useState('Positions')

  const totalPnl = useMemo(() => positions.reduce((sum, position) => sum + calculatePnl(position), 0), [positions])

  const addPosition = (position) => {
    setPositions((current) => [...current, { ...position, id: Date.now() }])
    setShowForm(false)
  }

  const removePosition = (id) => setPositions((current) => current.filter((position) => position.id !== id))

  return (
    <div className="trading-shell">
      <header className="trading-header">
        <div className="brand"><span className="brand-mark">Z</span><strong>Kite</strong></div>
        <div className="header-right"><span className="market-dot" /><span className="avatar">K</span></div>
      </header>

      <div className="trading-body">
        <aside className="sidebar">
          <div className="profile-mini"><div className="avatar large">K</div><div><strong>Account</strong><small>Portfolio</small></div></div>
          {['Dashboard', 'Watchlist', 'Orders', 'Positions', 'Holdings', 'Funds'].map((tab) => (
            <button key={tab} className={activeTab === tab ? 'side-item active' : 'side-item'} onClick={() => setActiveTab(tab)}>{tab}</button>
          ))}
        </aside>

        <main className="dashboard-main">
          <div className="mobile-tabs">
            {['Dashboard', 'Watchlist', 'Orders', 'Positions', 'Holdings', 'Funds'].map((tab) => (
              <button key={tab} className={activeTab === tab ? 'active' : ''} onClick={() => setActiveTab(tab)}>{tab}</button>
            ))}
          </div>

          {activeTab !== 'Positions' ? (
            <section className="empty-panel"><span className="empty-icon">⌁</span><h2>{activeTab}</h2><p>This demo screen is ready for the next module.</p><button className="primary-btn" onClick={() => setActiveTab('Positions')}>Open Positions</button></section>
          ) : (
            <>
              <div className="page-heading"><div><p className="eyebrow">PORTFOLIO</p><h1>Positions</h1><p>Intraday</p></div><button className="primary-btn" onClick={() => setShowForm(true)}>+ Add Position</button></div>

              <section className="pnl-card"><div><span>Total P&amp;L</span><strong className={totalPnl >= 0 ? 'positive' : 'negative'}>{money(totalPnl)}</strong></div><div className="pnl-meta"><span>{positions.length} positions</span></div></section>

              <section className="positions-card">
                <div className="table-title"><div><h2>Open Positions</h2></div></div>
                {positions.length === 0 ? <div className="empty-table">No positions yet. Add one to start.</div> : <div className="positions-list">{positions.map((position) => { const pnl = calculatePnl(position); return <article className="position-row" key={position.id}><div className="position-top"><div className="instrument"><strong>{position.symbol}</strong><small>NSE · EQ</small></div><span className={`direction ${position.direction.toLowerCase()}`}>{position.direction}</span><button className="delete-btn" onClick={() => removePosition(position.id)} aria-label={`Remove ${position.symbol}`}>×</button></div><div className="position-values"><div><span>Qty.</span><strong>{position.qty}</strong></div><div><span>Avg.</span><strong>₹{position.avg.toLocaleString('en-IN')}</strong></div><div><span>LTP</span><strong>₹{position.ltp.toLocaleString('en-IN')}</strong></div><div className="pnl-value"><span>P&amp;L</span><strong className={pnl >= 0 ? 'positive' : 'negative'}>{money(pnl)}</strong></div></div></article>})}</div>}
              </section>
            </>
          )}
        </main>
      </div>

      {showForm && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowForm(false)}><PositionForm onAdd={addPosition} onClose={() => setShowForm(false)} /></div>}
    </div>
  )
}
