import { useMemo, useState } from 'react'

const seedPositions = []

function money(value) {
  const sign = value >= 0 ? '+' : '-'
  return `${sign}₹${Math.abs(value).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`
}

function calculatePnl(position) {
  const difference = position.direction === 'BUY' ? position.ltp - position.avg : position.avg - position.ltp
  return difference * position.qty
}

function PositionForm({ onAdd, onClose }) {
  const [form, setForm] = useState({ symbol: '', qty: '', avg: '', ltp: '', direction: 'BUY' })
  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))
  const submit = (event) => {
    event.preventDefault()
    const symbol = form.symbol.trim().toUpperCase()
    const qty = Number(form.qty)
    const avg = Number(form.avg)
    const ltp = Number(form.ltp)
    if (!symbol || qty <= 0 || avg < 0 || ltp < 0) return
    onAdd({ symbol, qty, avg, ltp, direction: form.direction })
  }

  return (
    <form className="position-form" onSubmit={submit}>
      <div className="form-heading">
        <div><h3>Add position</h3><p>Enter position details</p></div>
        <button type="button" className="close-btn" onClick={onClose}>×</button>
      </div>
      <div className="direction-switch">
        <button type="button" className={form.direction === 'BUY' ? 'active buy' : ''} onClick={() => update('direction', 'BUY')}>BUY</button>
        <button type="button" className={form.direction === 'SELL' ? 'active sell' : ''} onClick={() => update('direction', 'SELL')}>SELL</button>
      </div>
      <label>Stock / Symbol<input value={form.symbol} onChange={(e) => update('symbol', e.target.value)} placeholder="RELIANCE" required /></label>
      <div className="form-grid">
        <label>Quantity<input type="number" min="1" value={form.qty} onChange={(e) => update('qty', e.target.value)} placeholder="100" required /></label>
        <label>Average price<input type="number" min="0" step="0.01" value={form.avg} onChange={(e) => update('avg', e.target.value)} placeholder="1400" required /></label>
        <label>LTP<input type="number" min="0" step="0.01" value={form.ltp} onChange={(e) => update('ltp', e.target.value)} placeholder="1470" required /></label>
      </div>
      <button className="primary-btn" type="submit">Add position</button>
    </form>
  )
}

function SearchIcon() { return <span className="kite-icon search-icon" aria-hidden="true" /> }
function FilterIcon() { return <span className="kite-icon filter-icon" aria-hidden="true" /> }
function GroupIcon() { return <span className="kite-icon group-icon" aria-hidden="true" /> }
function AnalyticsIcon() { return <span className="analytics-icon" aria-hidden="true" /> }
function BagIcon() { return <span className="bag-icon" aria-hidden="true" /> }
function FamilyIcon() { return <span className="family-icon" aria-hidden="true" /> }

export default function Dashboard() {
  const [positions, setPositions] = useState(seedPositions)
  const [showForm, setShowForm] = useState(false)
  const [activeTab, setActiveTab] = useState('Positions')
  const totalPnl = useMemo(() => positions.reduce((sum, position) => sum + calculatePnl(position), 0), [positions])

  const addPosition = (position) => {
    setPositions((current) => [...current, { ...position, id: Date.now() }])
    setShowForm(false)
  }
  const removePosition = (id) => setPositions((current) => current.filter((position) => position.id !== id))

  const tabs = ['Dashboard', 'Watchlist', 'Orders', 'Positions', 'Holdings', 'Funds']

  return (
    <div className="trading-shell">
      <header className="trading-header">
        <div className="mobile-portfolio-title">Portfolio</div>
        <div className="mobile-chevron" aria-hidden="true" />
        <div className="brand desktop-brand"><span className="brand-mark">Z</span><strong>Kite</strong></div>
        <div className="header-right desktop-header-right"><span className="market-dot" /><span className="avatar">K</span></div>
      </header>

      <div className="trading-body">
        <aside className="sidebar">
          <div className="profile-mini"><div className="avatar large">K</div><div><strong>Account</strong><small>Portfolio</small></div></div>
          {tabs.map((tab) => <button key={tab} className={activeTab === tab ? 'side-item active' : 'side-item'} onClick={() => setActiveTab(tab)}>{tab}</button>)}
        </aside>

        <main className="dashboard-main">
          <div className="mobile-tabs">
            <button className={activeTab === 'Holdings' ? 'active' : ''} onClick={() => setActiveTab('Holdings')}>Holdings</button>
            <button className={activeTab === 'Positions' ? 'active' : ''} onClick={() => setActiveTab('Positions')}>Positions</button>
          </div>

          {activeTab === 'Positions' ? (
            <>
              <div className="mobile-tools">
                <button aria-label="Search"><SearchIcon /></button>
                <button aria-label="Filter"><FilterIcon /></button>
                <button aria-label="Portfolio filter"><BagIcon /></button>
                <button className="equity-button" aria-label="Equity">Equity <span className="mini-chevron" /></button>
                <button className="family-button" aria-label="Family"><FamilyIcon /><span>Family</span></button>
                <button className="analytics-button" aria-label="Analytics"><AnalyticsIcon /><span>Analytics</span></button>
              </div>

              <div className="page-heading">
                <div><p className="eyebrow">PORTFOLIO</p><h1>Positions</h1><p>Intraday positions</p></div>
                <button className="primary-btn" onClick={() => setShowForm(true)}>+ Add position</button>
              </div>

              <section className="positions-card kite-positions-screen">
                {positions.length === 0 ? (
                  <div className="kite-empty-state">
                    <div className="empty-illustration" aria-hidden="true"><div className="paper one" /><div className="paper two" /><div className="paper three" /></div>
                    <h2>No positions</h2>
                    <p>Place an order from your watchlist</p>
                  </div>
                ) : (
                  <div className="positions-list">
                    {positions.map((position) => {
                      const pnl = calculatePnl(position)
                      const pnlPct = position.avg ? (pnl / (position.avg * position.qty)) * 100 : 0
                      const dayPnlPct = pnlPct
                      return (
                        <article className="kite-position" key={position.id}>
                          <div className="position-summary-row">
                            <div className="summary-left"><span>Qty. {position.qty}</span><span className="bullet">•</span><span>Avg. {position.avg.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
                            <strong className={pnlPct >= 0 ? 'positive' : 'negative'}>{pnlPct.toFixed(2)}%</strong>
                          </div>
                          <div className="position-main-row">
                            <div className="position-symbol-block">
                              <div className="position-symbol-line"><strong>{position.symbol}</strong><span className={`direction ${position.direction.toLowerCase()}`}>{position.direction}</span></div>
                              <span className="exchange-label">NSE · EQ</span>
                            </div>
                            <strong className={pnl >= 0 ? 'positive' : 'negative'}>{money(pnl)}</strong>
                          </div>
                          <div className="position-detail-row">
                            <div className="ltp-only"><span>LTP</span><strong>{position.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <em className={dayPnlPct >= 0 ? 'positive' : 'negative'}>({dayPnlPct >= 0 ? '+' : ''}{dayPnlPct.toFixed(2)}%)</em></strong></div>
                            <button className="delete-btn" onClick={() => removePosition(position.id)} aria-label={`Remove ${position.symbol}`}>×</button>
                          </div>
                        </article>
                      )
                    })}
                  </div>
                )}
              </section>

              <div className="day-pnl-bar">
                <span>Day's P&amp;L</span>
                <strong className={totalPnl >= 0 ? 'positive' : 'negative'}>{money(totalPnl)}</strong>
                <strong className={totalPnl >= 0 ? 'positive' : 'negative'}>{positions.reduce((sum, p) => sum + (p.avg ? (calculatePnl(p) / (p.avg * p.qty)) * 100 : 0), 0).toFixed(2)}%</strong>
              </div>
            </>
          ) : (
            <section className="empty-panel"><span className="empty-icon">⌁</span><h2>{activeTab}</h2><p>Nothing to show here yet.</p><button className="primary-btn" onClick={() => setActiveTab('Positions')}>Open positions</button></section>
          )}
        </main>
      </div>

      <button className="position-fab" onClick={() => setShowForm(true)} aria-label="Add position"><span className="fab-chart" /></button>

      <nav className="mobile-bottom-nav">
        <button onClick={() => setActiveTab('Watchlist')}><span className="nav-symbol bookmark" />Watchlist</button>
        <button onClick={() => setActiveTab('Orders')}><span className="nav-symbol orders" />Orders</button>
        <button className="active" onClick={() => setActiveTab('Positions')}><span className="nav-symbol portfolio" />Portfolio</button>
        <button onClick={() => setActiveTab('Bids')}><span className="nav-symbol bids" />Bids</button>
        <button onClick={() => setActiveTab('Funds')}><span className="nav-symbol profile" />Profile</button>
      </nav>

      {showForm && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowForm(false)}><PositionForm onAdd={addPosition} onClose={() => setShowForm(false)} /></div>}
    </div>
  )
}
