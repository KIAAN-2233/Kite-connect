# Zerodha Clone 2026 — Desktop Dashboard

This build is intentionally desktop-only. The existing React dashboard, watchlist, portfolio pages, positions table, orders, holdings, funds, and apps remain on the desktop dashboard architecture.

## Run

```bash
cd frontend
npm install
npm run start
```

Open the Vite URL shown in the terminal.

## Production build

```bash
cd frontend
npm install
npm run build
```

The production files are generated in `frontend/dist/`.
