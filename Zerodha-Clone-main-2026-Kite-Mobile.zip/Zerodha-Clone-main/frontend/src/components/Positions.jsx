import React from "react";
import { positions } from "../data/data";

const formatMoney = (value) => {
  const sign = value >= 0 ? "+" : "-";
  return `${sign}₹${Math.abs(value).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const PositionRow = ({ stock }) => {
  const side = stock.side || (stock.qty < 0 ? "SELL" : "BUY");
  const qty = Math.abs(stock.qty);
  const pnl = side === "SELL"
    ? (stock.avg - stock.price) * qty
    : (stock.price - stock.avg) * qty;
  const pnlClass = pnl >= 0 ? "position-profit" : "position-loss";
  const dayValue = parseFloat(String(stock.day || "0").replace("%", ""));
  const dayClass = dayValue >= 0 ? "position-profit" : "position-loss";

  return (
    <article className="kite-position-card">
      <div className="position-main-line">
        <div className="position-name-block">
          <div className="position-symbol-line">
            <span className="position-symbol">{stock.name}</span>
            <span className={`position-side ${side.toLowerCase()}`}>{side}</span>
          </div>
          <span className="position-exchange">NSE</span>
        </div>
        <div className={`position-pnl ${pnlClass}`}>{formatMoney(pnl)}</div>
      </div>

      <div className="position-metrics">
        <div>
          <span className="metric-label">Qty.</span>
          <span className="metric-value">{qty}</span>
        </div>
        <div>
          <span className="metric-label">Avg.</span>
          <span className="metric-value">{stock.avg.toFixed(2)}</span>
        </div>
        <div className="position-ltp">
          <span className="metric-label">LTP</span>
          <span className="metric-value">{stock.price.toFixed(2)}</span>
          <span className={dayClass}>{stock.day}</span>
        </div>
      </div>
    </article>
  );
};

const Positions = () => {
  const totalPnl = positions.reduce((total, stock) => {
    const side = stock.side || (stock.qty < 0 ? "SELL" : "BUY");
    const qty = Math.abs(stock.qty);
    return total + (side === "SELL" ? (stock.avg - stock.price) * qty : (stock.price - stock.avg) * qty);
  }, 0);

  return (
    <section className="positions-page">
      <header className="kite-mobile-header">
        <button className="portfolio-title" type="button" aria-label="Portfolio menu">
          <span>Portfolio</span>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5" /></svg>
        </button>
      </header>

      <div className="portfolio-tabs" role="tablist">
        <button type="button" className="portfolio-tab" role="tab">Holdings <span>{positions.length + 5}</span></button>
        <button type="button" className="portfolio-tab active" role="tab" aria-selected="true">Positions <span>{positions.length}</span></button>
      </div>

      <div className="total-pnl-card">
        <span>Total P&amp;L</span>
        <strong className={totalPnl >= 0 ? "position-profit" : "position-loss"}>{formatMoney(totalPnl)}</strong>
      </div>

      <div className="positions-toolbar">
        <button type="button" aria-label="Search positions">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></svg>
          <span>Search</span>
        </button>
        <button type="button" aria-label="Filter positions">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 6h14M8 12h8M10 18h4" /></svg>
          <span>Filter</span>
        </button>
        <button type="button" className="toolbar-spacer" aria-label="Analytics">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19V10M12 19V5M19 19v-8" /></svg>
          <span>Analytics</span>
        </button>
      </div>

      <div className="positions-list">
        {positions.map((stock, index) => <PositionRow stock={stock} key={`${stock.name}-${index}`} />)}
      </div>

      <div className="day-pnl-bar">
        <span>Day&apos;s P&amp;L</span>
        <strong className={totalPnl >= 0 ? "position-profit" : "position-loss"}>{formatMoney(totalPnl)}</strong>
      </div>

      <button className="analytics-fab" type="button" aria-label="Open analytics">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19V10M12 19V5M19 19v-8" /></svg>
      </button>

      <nav className="kite-bottom-nav" aria-label="Primary navigation">
        <a href="#watchlist"><span className="nav-icon">⌂</span><span>Watchlist</span></a>
        <a href="#orders"><span className="nav-icon">▤</span><span>Orders</span></a>
        <a href="#portfolio" className="active"><span className="nav-icon">▥</span><span>Portfolio</span></a>
        <a href="#bids"><span className="nav-icon">◫</span><span>Bids</span></a>
        <a href="#profile"><span className="nav-icon">●</span><span>Profile</span></a>
      </nav>
    </section>
  );
};

export default Positions;
